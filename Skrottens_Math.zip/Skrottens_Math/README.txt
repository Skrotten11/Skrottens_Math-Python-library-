Welcome to Skrottens Math! This is a simple math library containing the following functions:

add()
substract()
multiply()
divide()

How to use:
   -If you for example wish to add two numbers, use the add function like this: Skrottens_Math.add(value1, value2)
    This will return the answer. The other functions are used completely similar.

Note: This library is just a test-project i made to learn making libraries- Though it is fully functional and correct!

Thanks for reading!!