def add(value1, value2):
    return value1 + value2

def substract(value1, value2):
    return value1 - value2

def multiply(value1, value2):
    return value1 * value2

def divide(value1, value2):
    return value1 / value2
